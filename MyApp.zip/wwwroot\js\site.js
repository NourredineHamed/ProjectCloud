console.log("Products page loaded!");
